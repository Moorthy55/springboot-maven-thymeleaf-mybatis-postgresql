package com.example.demo.mapper;

import java.util.LinkedHashSet;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import com.example.demo.domain.Item;

@Mapper
public interface ItemMapper {
	List<Item> findAll();

	LinkedHashSet<Item> findOne(String search_input);

}
