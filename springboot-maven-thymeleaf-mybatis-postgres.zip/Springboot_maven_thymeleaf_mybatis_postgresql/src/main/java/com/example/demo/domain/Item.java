package com.example.demo.domain;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

public class Item {
	public String ktrg_no;
	public String prdct_nm_jp;
	public String prdct_nm_en;
	public String prdct_ktsk;
	public String iri_su;
	public String lst_price;
	public String curr_cd;
	public String mkt_price_kbn;
	public String grn_skbt_kbn;
	public String sell_price;
	public String keyword;

	public String getktrg_no() {
		return ktrg_no;
	}

	public void setktrg_no(String ktrg_no) {
		this.ktrg_no = ktrg_no;
	}

	public String getprdct_nm_jp() {
		return prdct_nm_jp;
	}

	public void setprdct_nm_jp(String prdct_nm_jp) {
		this.prdct_nm_jp = prdct_nm_jp;
	}

	public String getprdct_nm_en() {
		return prdct_nm_en;
	}

	public void setprdct_nm_en(String prdct_nm_en) {
		this.prdct_nm_en = prdct_nm_en;
	}

	public String getprdct_ktsk() {
		return prdct_ktsk;
	}

	public void setprdct_ktsk(String prdct_ktsk) {
		this.prdct_ktsk = prdct_ktsk;
	}

	public String getiri_su() {
		return iri_su;
	}

	public void setiri_su(String iri_su) {
		this.iri_su = iri_su;
	}

	public String getlst_price() {
		return lst_price;
	}

	public void setlst_price(String lst_price) {
		this.lst_price = lst_price;
	}

	public String getcurr_cd() {
		return curr_cd;
	}

	public void setcurr_cd(String curr_cd) {
		this.curr_cd = curr_cd;
	}

	public String getmkt_price_kbn() {
		return mkt_price_kbn;
	}

	public void setmkt_price_kbn(String mkt_price_kbn) {
		this.mkt_price_kbn = mkt_price_kbn;
	}

	public String getgrn_skbt_kbn() {
		return grn_skbt_kbn;
	}

	public void setgrn_skbt_kbn(String grn_skbt_kbn) {
		this.grn_skbt_kbn = grn_skbt_kbn;
	}

	public String getsell_price() {
		return sell_price;
	}

	public void setsell_price(String sell_price) {
		this.sell_price = sell_price;
	}

	public String getkeyword() {
		return keyword;
	}

	public void setkeyword(String keyword) {
		this.keyword = keyword;
	}
}
